<?php 
include_once __DIR__.'/../include/db/db_connect.php';
include_once __DIR__.'/../include/func.php';
include_once __DIR__."/../{$_GET['type']}/check_login.php";
include_once __DIR__.'/../include/default_head.php';
?>
<link href="<?=$_GET['type']?>/assets/style.css" rel="stylesheet">
<?php

    if(!check_login())
        include __DIR__."/../{$_GET['type']}/pages/login/login.php";
        
    else{
        if(isset($_GET['page'])){
            include_once __DIR__."/../{$_GET['type']}/check_chmod.php"; if(!check_chmod())exit('<div class="alert alert-danger">У вас нет доступа к разделу<div>');
            include_once __DIR__."/../{$_GET['type']}/pages/menu.php";
            $param = explode('_' , $_GET['page']); // разбиваем параметры _ и инклюдим нужный файл
                //если 1 часть в странице
            if (count($param) == 1 && file_exists(__DIR__."/../{$_GET['type']}/pages/".$param[0].'/'.$param[0].'.php')) include(__DIR__."/../{$_GET['type']}/pages/".$param[0].'/'.$param[0].'.php');                               //если 2 части в странице
            if (count($param) == 2 && file_exists(__DIR__."/../{$_GET['type']}/pages/".$param[0].'/'.$param[1].'/index.php'))include(__DIR__."/../{$_GET['type']}/pages/".$param[0].'/'.$param[1].'/index.php');                  //если 3 части в странице
            if (count($param) == 3 && file_exists(__DIR__."/../{$_GET['type']}/pages/".$param[0].'/'.$param[1].'/'.$param[2].'/index.php'))include(__DIR__."/../{$_GET['type']}/pages/".$param[0].'/'.$param[1].'/'.$param[2].'/index.php');    //если 3 части в странице
            
        }
    }
?>



<?php include_once __DIR__.'/../include/default_footer.php' ?>