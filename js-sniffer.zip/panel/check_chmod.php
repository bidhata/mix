<?php

//Функция проверки доступа к разделу
function check_chmod(){
    
    if(empty($_SESSION["chmod"])) return false;
    
    else{
        $array = json_decode($_SESSION["chmod"] , true);
        if(array_search("{$_GET['page']}" , $array) !== false){
            return true;
        }
        else{
            return false;
        }
    }
}


//Функция проверки доступа к разделу передаваемому в функции
function check_chmod_custom($chmod){
    
    if(empty($_SESSION["chmod"])) return false;
    
    else{
        $array = json_decode($_SESSION["chmod"] , true);
        if(array_search("{$chmod}" , $array) !== false){
            return true;
        }
        else{
            return false;
        }
    }
}


