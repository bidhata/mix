<?php

function check_login(){
    
    if(!isset($_SESSION['token']) || !isset($_SESSION['login']) || !isset($_SESSION['token']) || !isset($_SESSION['chmod']) || !isset($_SESSION['id'])){
        return false;
    }
    
    else{
        
       if($_SESSION['token'] == hash('whirlpool', ($_SERVER['HTTP_USER_AGENT'].$_SESSION['login'].$_SESSION['password'].$_SESSION['id'].$_SESSION['chmod'])))
            return true;
        else
            return false;
    }



}

?>