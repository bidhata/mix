<?php
if($_SERVER['SCRIPT_NAME'] !='/index.php') exit('Идите пожалуйста нахуй отсюдава');

include_once 'include/db/db_connect.php';
include_once 'include/geoip.php';
?>

<script src="assets/js/chartkick.js"></script>
<script src="assets/js/loader.js"></script>

<?php
// Get cilent stat
$total_cilents = count($db->getCol( 'SELECT id FROM bots WHERE 1'));
$online = count($db->getCol( 'SELECT id FROM bots WHERE last_seen >= ?i' , date('U')-300 ));
$online_perc = round(($online / $total_cilents) * 100, 2);
$online_24 = count($db->getCol( 'SELECT id FROM bots WHERE last_seen >= ?i' , date('U')-86400 ));
$dead = count($db->getCol( 'SELECT id FROM bots WHERE last_seen <= ?i' , date('U')-604800 ));


// Get reports stat
$total_reports = count($db->getCol( 'SELECT id FROM reports WHERE 1'));
$reports_24 = count($db->getCol( 'SELECT id FROM reports WHERE received >= ?i' , date('U')-86400));
?>


<?php
$country = $db->getAll('SELECT DISTINCT country, COUNT(*) as num FROM bots GROUP BY country ORDER BY num DESC');
$geoip = new GeoIP();
foreach($country as $country)
      $map .= '["'.$geoip->GEOIP_COUNTRY_NAMES[$geoip->GEOIP_COUNTRY_CODE_TO_NUMBER[$country['country']]].'"' . ',' . format_count($country['num']) . '],';

$map = rtrim($map,", ");

?>



<div class="container mgt-30">
    
    <div class="col-md-12">
    <div class="box-standart">
    <div class="box-head" role="tab" id="headingOne">
      <h5 class="mb-0">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          Countries Map
        </a>
      </h5>
    </div>

    <div id="collapseOne" class="collapse" role="tabpanel" aria-labelledby="headingOne">
      <div class="card-block " style="height: 450px; padding: 0px;">
       <center><div id="chart-1" style="background-color:#fff;height: 550px"></div></center>
          <?php echo "
          <script> new Chartkick.GeoChart( \"chart-1\",[{$map}] ); </script>";  ?>
      </div>
    </div>
    </div>
    </div>
    
    <p></p>
    <o></o>
    <t></t>
    <e></e>
    <r></r>
    
    
    <div class="row">
       <div class="col-md-6">
           <div class="col-md-12 mgt-20">
           <div class="box-standart">
            <div class="box-head"><h4>Cilents</h4></div>
                <div class="box-content">
                    <table class="table table-hover table-tasks">
                    <tr>
                        <td>Total Cilents:</td>
                        <td><?=$total_cilents?></td>
                    </tr>
                    <tr>
                        <td>Online Cilents:</td>
                        <td><?=$online?> (<?=$online_perc?>%)</td>
                    </tr>
                    <tr>
                        <td>Cilents (24 hours):</td>
                        <td><?=$online_24?></td>
                    </tr>
                    <tr>
                        <td>Probably dead:</td>
                        <td><?=$dead?></td>
                    </tr>
                    </table>
                </div>
           </div>
            </div>
        
           <div class="col-md-12 mgt-20">
           <div class="box-standart">
            <div class="box-head"><h4>Reports</h4></div>
                <div class="box-content">
                    <table class="table table-hover table-tasks">
                    <tr>
                        <td>Total Reports:</td>
                        <td><?=$total_reports?></td>
                    </tr>
                    <tr>
                        <td>24 hours Reports:</td>
                        <td><?=$reports_24?></td>
                    </tr>
                    </table>
                </div>
           </div>
           </div>
       </div>
   
    
    
    
        
       <div class="col-md-6">
           <div class="col-md-12 mgt-20">
           <div class="box-standart">
            <div class="box-head"><h4>OS Stat</h4></div>
                <div class="box-content">
                    <table class="table table-hover table-tasks">
                    <?php
                    //OS ver
                    $os = array();
                    foreach ($db->getAll('SELECT os_major, os_minor, is_server FROM bots WHERE 1') as $bot){
                        $osName = get_os($bot['os_major'], $bot['os_minor'], $bot['is_server']);
                        
                        if(isset($os[$osName]))
                           ++$os[$osName];
                        else
                            $os[$osName] = 1;
                    }
                            
                    foreach ($os as $name => $count){
                        echo "<tr><td>{$name}:</td><td>{$count} (".round(($count / $total_cilents) * 100, 2)."%) </td></tr>";
                    }
                    ?>
                        <tr><td></td><td></td></tr>
                    <?php
                    //OS X
                    $arc = $db->getOne('SELECT  COUNT(*) FROM bots WHERE is_x64=1');
                            echo "<tr><td>x64:</td><td>{$arc} (".round(($arc / $total_cilents) * 100, 2)."%) </td></tr>";
                            
                    ?>
                        <tr><td>x86:</td><td><?=$total_cilents-$arc?> (<?=round((($total_cilents-$arc) / $total_cilents) * 100, 2)?>%) </td></tr>
                    </table>
                </div>
           </div>
           </div>
       </div>
    </div>

</div>
