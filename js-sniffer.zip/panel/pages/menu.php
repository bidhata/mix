


<nav class="navbar navbar-toggleable-md navbar-light bg-faded">
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="#"><img src='assets/img/logo.png'></a>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      
     
    

<?php


if(check_chmod_custom('logs')) echo "<li class='nav-item'><a class='nav-link' href='./?type=panel&page=logs'><button class='btn btn-sm align-middle btn-outline-primary' type='button'><i class='fa fa-list-alt'></i> Logs</button></a></li>";
       
if(check_chmod_custom('generator')) echo "<li class='nav-item'><a class='nav-link' href='./?type=panel&page=generator'><button class='btn btn-sm align-middle btn-outline-primary' type='button'><i class='fa fa-refresh'></i> Generator</button></a></li>";
        
if(check_chmod_custom('settings')) echo "<li class='nav-item'><a class='nav-link' href='./?type=panel&page=settings'><button class='btn btn-sm align-middle btn-outline-primary' type='button'><i class='fa fa-cog'></i> Settings</button></a></li>";      

      

        
echo "<li class='nav-item'><a class='nav-link' href='./?type=logout'><button class='btn btn-sm align-middle btn-outline-primary' type='button'></i> <i class='fa fa-power-off'></i></button></a></li>";
?>
        
        </ul>
  </div>
</nav>