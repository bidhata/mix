<?php
include_once __DIR__."/../../check_chmod.php";
if(!check_chmod_custom('settings')) exit('Идите пожалуйста нахуй отсюдава');
?>

<div class="container">
    <div class="box-standart mgt-30">
    <div class="box-head" role="tab" id="headingOne"><h4>Settings</h4></div>
        
    <div class="box-content">
    <div class="form-group col-md-6 mgt-20">
        <label for="old-password">Old password</label>
        <input id="old-password" type="password" class="form-control" aria-label="Old password">
    </div>
    
    <div class="form-group col-md-6 mgt-20">
        <label for="new-password">New password</label>
        <input id="new-password" type="password" class="form-control" aria-label="Old password">
    </div>
    
    <div class="input-group col-md-6 mgt-20">
        <button onclick="save_password()" class="btn btn-primary">Save</button>
    </div>
    
    
    </div>
</div>
</div>


<script>
    function save_password(){
    
        if( $('#old-password').val().length <4 ) {show_error('Введите старый пароль');return false;}
        if( $('#new-password').val().length <6 ) {show_error('Новый пароль слишком короткий');return false;}
        
        $('#modal-loading').modal({show:true,  backdrop: 'static', keyboard: false }); 
        $.post( "<?=$_GET['type']?>/ajax.php", { 
            type: 'save_password',
            old_password: $('#old-password').val(),
            new_password: $('#new-password').val()
        })
         .done(function( data ) {
            $('#modal-loading').modal('hide');
            if(data == 'oldpass') show_error('Старый пароль не верный, либо новый не достаточной длинны.');
            if(data == '') show_error('Неизвесная ошибка.');
            if(data == 'ok') show_success('Новый пароль успешно задан.');
         });
    }
    
    
</script>