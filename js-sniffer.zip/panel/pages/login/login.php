<?php
    if(isset($_POST['login']) && isset($_POST['password'])){
        include_once __DIR__.'/../../../include/db/db_connect.php';
        $check = $db->getRow('SELECT * FROM users WHERE login=?s AND password=?s' , $_POST['login'], hash('whirlpool', $_POST['password']));
        if(isset($check['id'])){
            $_SESSION['login'] = $check['login'];
            $_SESSION['jabber'] = $check['jabber'];
            $_SESSION['password'] = $check['password'];
            $_SESSION['id'] = $check['id'];
            $_SESSION['chmod'] = $check['chmod'];
            $_SESSION['token'] = hash('whirlpool', ($_SERVER['HTTP_USER_AGENT'].$_SESSION['login'].$_SESSION['password'].$_SESSION['id'].$_SESSION['chmod']));
            
            echo '<div class="alert alert-success">Login ok. Redirecting in 3 sec...</div><script>setTimeout(\'location.href="./?type='.$_GET['type'].'&page=logs"\' , 3000)</script>';
        }
        else{
            $db->query('UPDATE users SET fails=fails+1 WHERE login=?s' , $_POST['login']);
            echo '<div class="alert alert-danger">Login Error</div>';}
    
    }
    
?>
<div class="container login-div mgt-20">
    
    
    
    <form method="post" action="" onsubmit="return check_form()">
        <div class="input-group">
            <input required type="text" name="login" id="login" class="form-control" aria-label="Login" placeholder="Login">
        </div>
        
        <div class="input-group mgt-20">
            <input required type="password" name="password" id="password" class="form-control" aria-label="Password" placeholder="Password">
        </div>
        
        <div class="input-group mgt-20 w-100">
            <button class="btn btn-primary w-100">Login</button>
        </div>
    </form>
</div>


<script>
function check_form(){
    if($('#login').val().length < 5){
        $('#modal-message .alert-danger span').html('Login must be no less than 5 letters');
        $('#modal-message .alert-danger').show()
        $('#modal-message').modal('show');
        return false;
    }
    
    if($('#password').val().length < 5){
        $('#modal-message .alert-danger span').html('Login must be no less than 5 letters');
         $('#modal-message .alert-danger').show()
        $('#modal-message').modal('show');
        return false;
    }
}
</script>
