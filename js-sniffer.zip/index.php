<?php
session_start();

if(isset($_GET['type'])){
    if ($_GET['type'] == 'logout') {session_destroy();header("Location: ./?type=panel&page=logs");}
    if (file_exists($_GET['type'] . '/index.php'))
        include_once $_GET['type'] . '/index.php';
    else
        exit('Error');
}

else{
    exit;
}