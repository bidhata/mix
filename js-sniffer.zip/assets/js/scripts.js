function show_error(text){
    $('#modal-message .alert-danger span').html(text);
    $('#modal-message .alert-info').hide();$('#modal-message .alert-warning').hide();$('#modal-message .alert-danger').hide();$('#modal-message .alert-success').hide();
    $('#modal-message .alert-danger').show();
    $('#modal-message').modal('show');
}

function show_success(text){
    $('#modal-message .alert-success span').html(text);
    $('#modal-message .alert-info').hide();$('#modal-message .alert-warning').hide();$('#modal-message .alert-danger').hide();$('#modal-message .alert-success').hide();
    $('#modal-message .alert-success').show();
    $('#modal-message').modal('show');
}

function show_warning(text){
    $('#modal-message .alert-warning span').html(text);
    $('#modal-message .alert-info').hide();$('#modal-message .alert-warning').hide();$('#modal-message .alert-danger').hide();$('#modal-message .alert-success').hide();
    $('#modal-message .alert-warning').show();
    $('#modal-message').modal('show');
}

function show_info(text){
    $('#modal-message .alert-info span').html(text);
    $('#modal-message .alert-info').hide();$('#modal-message .alert-warning').hide();$('#modal-message .alert-danger').hide();$('#modal-message .alert-success').hide();
    $('#modal-message .alert-info').show();
    $('#modal-message').modal('show');
}

function copyToClipboard(tocopy) {
  var $temp = $("<input>");
  $("body").append($temp);
  $temp.val(tocopy).select();
  document.execCommand("copy");
  $temp.remove();
  show_error('123');  
}