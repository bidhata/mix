<?php
if($_SERVER['SCRIPT_NAME'] !='/index.php') exit('Идите пожалуйста нахуй отсюдава');
?>


<div class="pages_navigation ">

<?php
     
     while ($page++ < $num_pages){
        if ($page == $cur_page)
            echo "<div class='btn-group' role='group'><button type='button' disabled class='btn btn-secondary'>{$page}</button></div>";
        else
            echo "<div class='btn-group' role='group'><a href='./?type={$_GET['type']}&page={$_GET['page']}&num_page={$page}'><button type='button' class='btn btn-secondary'>{$page}</button></a></div>";
    }
     
?>
</div>