<?php
	include_once "config.php";
	include_once "safemysql.php"; 
    $db = new SafeMySQL(array("host" => DB_HOST, "user" => DB_USER, "pass" => DB_PASS, "db" => DB_DATABASE, "charset" => 'utf8', "port" => DB_PORT));
?>