<?php
ini_set('date.timezone', 'Europe/Moscow');
// DATABASE
define("DB_HOST","localhost"); // IP базы
define("DB_PORT","3306"); // порт базы
define("DB_USER","js"); // имя пользователя базы данных
define("DB_PASS","AuschwitzN732015"); // пароль базы данных
define("DB_DATABASE","js"); // название используемой базы данных

define("SECURE", FALSE);
?>
