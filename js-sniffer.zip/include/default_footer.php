        <script src="assets/js/jquery-3.1.1.min.js"></script>
        <script src="assets/js/tether.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/scripts.js"></script>
  


<div id="modal-loading" class="modal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      
      <div class="modal-body">
        <center><img src="assets/img/loading.gif"></center>
      </div>
      
    </div>
  </div>
</div>


<div id="modal-message" class="modal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body">
            <div class="alert alert-danger"><strong>Error. </strong>   <span></span></div>
            <div class="alert alert-info"><strong>Info. </strong>    <span></span></div>
            <div class="alert alert-success"><strong>Success. </strong> <span></span></div>
            <div class="alert alert-warning"><strong>Warning. </strong> <span></span></div>
      </div>
      
    </div>
  </div>
</div>

<script>
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })
</script>


</body>
</html>